import { and, desc, eq, gt, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { ENV } from "./_core/env";
import {
  categories,
  InsertUser,
  users,
  videos,
  adminLoginAttempts,
  adminSessions,
} from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

function requireDb(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new Error("Database is not available");
  return db;
}

export async function incrementAdminLoginAttempt(clientKey: string, now = new Date(), windowMs = 15 * 60 * 1000) {
  const db = requireDb(await getDb());
  const cutoff = new Date(now.getTime() - windowMs);
  await db.delete(adminLoginAttempts).where(lte(adminLoginAttempts.windowStartedAt, cutoff));
  await db.insert(adminLoginAttempts).values({ clientKey, attempts: 1, windowStartedAt: now, updatedAt: now }).onDuplicateKeyUpdate({
    set: {
      attempts: sql`IF(${adminLoginAttempts.windowStartedAt} <= ${cutoff}, 1, ${adminLoginAttempts.attempts} + 1)`,
      windowStartedAt: sql`IF(${adminLoginAttempts.windowStartedAt} <= ${cutoff}, ${now}, ${adminLoginAttempts.windowStartedAt})`,
      updatedAt: now,
    },
  });
  const rows = await db.select({ attempts: adminLoginAttempts.attempts }).from(adminLoginAttempts).where(eq(adminLoginAttempts.clientKey, clientKey)).limit(1);
  return rows[0]?.attempts ?? 0;
}

export async function createAdminSession(id: string, expiresAt: Date) {
  const db = requireDb(await getDb());
  await db.insert(adminSessions).values({ id, expiresAt });
  await db.delete(adminSessions).where(lte(adminSessions.expiresAt, new Date()));
}

export async function isAdminSessionActive(id: string, now = new Date()) {
  const db = await getDb();
  if (!db) return false;
  const rows = await db.select({ id: adminSessions.id }).from(adminSessions).where(and(eq(adminSessions.id, id), gt(adminSessions.expiresAt, now))).limit(1);
  return rows.length > 0;
}

export async function revokeAdminSession(id: string) {
  const db = requireDb(await getDb());
  await db.delete(adminSessions).where(eq(adminSessions.id, id));
  return { success: true as const };
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = requireDb(await getDb());
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    values.lastSignedIn ??= new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories).orderBy(categories.name).limit(200);
}

export async function createCategory(name: string, slug: string) {
  const db = requireDb(await getDb());
  const result = await db.insert(categories).values({ name, slug });
  return db.select().from(categories).where(eq(categories.id, Number(result[0].insertId))).limit(1).then(rows => rows[0]);
}

export async function updateCategory(id: number, name: string, slug: string) {
  const db = requireDb(await getDb());
  await db.update(categories).set({ name, slug }).where(eq(categories.id, id));
  const rows = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function deleteCategory(id: number) {
  const db = requireDb(await getDb());
  await db.update(videos).set({ categoryId: null }).where(eq(videos.categoryId, id));
  await db.delete(categories).where(eq(categories.id, id));
}

export async function listVideos() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: videos.id,
      title: videos.title,
      description: videos.description,
      videoUrl: videos.videoUrl,
      thumbnailUrl: videos.thumbnailUrl,
      categoryId: videos.categoryId,
      categoryName: categories.name,
      createdAt: videos.createdAt,
    })
    .from(videos)
    .leftJoin(categories, eq(videos.categoryId, categories.id))
    .orderBy(desc(videos.createdAt))
    .limit(200);
}

export async function getVideoById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select({
      id: videos.id,
      title: videos.title,
      description: videos.description,
      videoUrl: videos.videoUrl,
      thumbnailUrl: videos.thumbnailUrl,
      categoryId: videos.categoryId,
      categoryName: categories.name,
      createdAt: videos.createdAt,
    })
    .from(videos)
    .leftJoin(categories, eq(videos.categoryId, categories.id))
    .where(eq(videos.id, id))
    .limit(1);
  return rows[0] ?? null;
}

export type VideoInput = {
  title: string;
  description?: string | null;
  videoUrl: string;
  thumbnailUrl?: string | null;
  categoryId?: number | null;
};

export async function createVideo(input: VideoInput) {
  const db = requireDb(await getDb());
  const result = await db.insert(videos).values({
    title: input.title,
    description: input.description ?? null,
    videoUrl: input.videoUrl,
    thumbnailUrl: input.thumbnailUrl ?? null,
    categoryId: input.categoryId ?? null,
  });
  return getVideoById(Number(result[0].insertId));
}

export async function updateVideo(id: number, input: VideoInput) {
  const db = requireDb(await getDb());
  await db.update(videos).set({
    title: input.title,
    description: input.description ?? null,
    videoUrl: input.videoUrl,
    thumbnailUrl: input.thumbnailUrl ?? null,
    categoryId: input.categoryId ?? null,
  }).where(eq(videos.id, id));
  return getVideoById(id);
}

export async function deleteVideo(id: number) {
  const db = requireDb(await getDb());
  await db.delete(videos).where(eq(videos.id, id));
}
