import { COOKIE_NAME } from "@shared/const";
import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { getAdminSession } from "./adminSession";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  adminSession: boolean;
  adminSessionId: string | null;
};

function hasCookie(cookieHeader: string | undefined, name: string) {
  return (cookieHeader ?? "").split(";").some(part => part.trim().startsWith(`${name}=`));
}

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  const authorization = opts.req.headers.authorization;
  const bearerToken = typeof authorization === "string" && authorization.startsWith("Bearer ")
    ? authorization.slice(7)
    : undefined;
  const session = await getAdminSession(bearerToken);
  if (session && await db.isAdminSessionActive(session.sessionId)) {
    return { req: opts.req, res: opts.res, user: session.user, adminSession: true, adminSessionId: session.sessionId };
  }

  let user: User | null = null;
  const hasManusSession = hasCookie(opts.req.headers.cookie, COOKIE_NAME);
  if (hasManusSession || bearerToken) {
    try {
      user = await sdk.authenticateRequest(opts.req);
    } catch {
      user = null;
    }
  }

  return { req: opts.req, res: opts.res, user, adminSession: false, adminSessionId: null };
}
