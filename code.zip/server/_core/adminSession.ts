import { randomUUID } from "node:crypto";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import { ENV } from "./env";

const ADMIN_SUBJECT = "cliphub-admin";
const SESSION_LIFETIME_SECONDS = 2 * 60 * 60;

function signingKey() {
  if (!ENV.cookieSecret || !ENV.appId) {
    throw new Error("Admin session signing configuration is unavailable");
  }
  return new TextEncoder().encode(ENV.cookieSecret);
}

export async function createAdminSessionToken() {
  const sessionId = randomUUID();
  const expiresAt = new Date(Date.now() + SESSION_LIFETIME_SECONDS * 1000);
  const token = await new SignJWT({ appId: ENV.appId, role: "admin" })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setSubject(ADMIN_SUBJECT)
    .setJti(sessionId)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_LIFETIME_SECONDS}s`)
    .sign(signingKey());
  return { sessionId, expiresAt, token };
}

export async function getAdminSession(token?: string): Promise<{ user: User; sessionId: string } | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, signingKey(), { algorithms: ["HS256"] });
    if (payload.sub !== ADMIN_SUBJECT || payload.appId !== ENV.appId || payload.role !== "admin" || typeof payload.jti !== "string") return null;
    const now = new Date();
    return {
      sessionId: payload.jti,
      user: {
        id: 0,
        openId: ADMIN_SUBJECT,
        name: "ผู้ดูแล ClipHub",
        email: null,
        loginMethod: "password",
        role: "admin",
        createdAt: now,
        updatedAt: now,
        lastSignedIn: now,
      },
    };
  } catch {
    return null;
  }
}
