import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { storagePut } from "./storage";
import * as db from "./db";
import { COOKIE_NAME } from "@shared/const";
import { ENV } from "./_core/env";
import { createAdminSessionToken } from "./_core/adminSession";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";

const videoFields = z.object({
  title: z.string().trim().min(1).max(180),
  description: z.string().max(5000).optional().nullable(),
  videoUrl: z.string().url().max(2048),
  thumbnailUrl: z.string().max(1024).optional().nullable(),
  categoryId: z.number().int().positive().optional().nullable(),
});

const categoryName = z.string().trim().min(1).max(80);

function slugify(value: string) {
  return value
    .toLocaleLowerCase("th")
    .normalize("NFKC")
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "") || `category-${Date.now()}`;
}

function secretMatches(candidate: string, configured: string) {
  const candidateDigest = createHash("sha256").update(candidate, "utf8").digest();
  const configuredDigest = createHash("sha256").update(configured, "utf8").digest();
  return timingSafeEqual(candidateDigest, configuredDigest);
}

const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 8;

const videosRouter = router({
  list: publicProcedure.query(() => db.listVideos()),
  byId: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => db.getVideoById(input.id)),
  adminList: adminProcedure.query(() => db.listVideos()),
  create: adminProcedure.input(videoFields).mutation(({ input }) => db.createVideo(input)),
  update: adminProcedure.input(videoFields.extend({ id: z.number().int().positive() })).mutation(({ input }) => {
    const { id, ...video } = input;
    return db.updateVideo(id, video);
  }),
  delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => db.deleteVideo(input.id).then(() => ({ success: true as const }))),
  uploadThumbnail: adminProcedure.input(z.object({
    fileName: z.string().trim().min(1).max(180),
    mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]),
    base64Content: z.string().min(1).max(7_000_000),
  })).mutation(async ({ input }) => {
    const bytes = Buffer.from(input.base64Content, "base64");
    if (bytes.length === 0 || bytes.length > 5 * 1024 * 1024) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "ไฟล์ภาพต้องมีขนาดไม่เกิน 5 MB" });
    }
    const signatures: Record<string, boolean> = {
      "image/jpeg": bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff,
      "image/png": bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])),
      "image/webp": bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP",
    };
    if (!signatures[input.mimeType]) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "ไฟล์ภาพไม่ตรงกับชนิดไฟล์ที่ระบุ" });
    }
    const extension = input.mimeType === "image/jpeg" ? "jpg" : input.mimeType.split("/")[1];
    try {
      const uploaded = await storagePut(`cliphub/covers/${crypto.randomUUID()}.${extension}`, bytes, input.mimeType);
      return { thumbnailUrl: uploaded.url };
    } catch (error) {
      console.error("[ClipHub] Thumbnail upload failed:", error instanceof Error ? error.message : "unknown error");
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "อัปโหลดภาพปกไม่สำเร็จ กรุณาลองอีกครั้ง" });
    }
  }),
});

const categoriesRouter = router({
  list: publicProcedure.query(() => db.listCategories()),
  adminList: adminProcedure.query(() => db.listCategories()),
  create: adminProcedure.input(z.object({ name: categoryName })).mutation(({ input }) => db.createCategory(input.name, slugify(input.name))),
  update: adminProcedure.input(z.object({ id: z.number().int().positive(), name: categoryName })).mutation(({ input }) => db.updateCategory(input.id, input.name, slugify(input.name))),
  delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => db.deleteCategory(input.id).then(() => ({ success: true as const }))),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    adminMe: publicProcedure.query(({ ctx }) => ({ authenticated: ctx.adminSession })),
    adminLogin: publicProcedure.input(z.object({
      username: z.string().trim().min(1).max(128),
      password: z.string().min(1).max(256),
    })).mutation(async ({ ctx, input }) => {
      const clientId = ctx.req.ip || ctx.req.socket.remoteAddress || "unknown";
      const clientKey = createHmac("sha256", ENV.cookieSecret).update(clientId).digest("hex");
      const attempts = await db.incrementAdminLoginAttempt(clientKey, new Date(), LOGIN_WINDOW_MS);
      if (attempts > MAX_LOGIN_ATTEMPTS) {
        throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "ลองเข้าสู่ระบบใหม่อีกครั้งในอีก 15 นาที" });
      }
      if (!ENV.adminUsername || !ENV.adminPassword) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "ยังไม่ได้ตั้งค่าบัญชีผู้ดูแล" });
      }
      const usernameMatches = secretMatches(input.username.toLocaleLowerCase("en"), ENV.adminUsername.trim().toLocaleLowerCase("en"));
      const passwordMatches = secretMatches(input.password, ENV.adminPassword);
      if (!usernameMatches || !passwordMatches) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
      }
      const session = await createAdminSessionToken();
      await db.createAdminSession(session.sessionId, session.expiresAt);
      return { success: true as const, token: session.token };
    }),
    adminLogout: publicProcedure.mutation(({ ctx }) => ctx.adminSessionId ? db.revokeAdminSession(ctx.adminSessionId) : ({ success: true as const })),
  }),
  videos: videosRouter,
  categories: categoriesRouter,
});

export type AppRouter = typeof appRouter;
