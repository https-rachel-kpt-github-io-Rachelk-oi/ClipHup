export type DemoVideo = {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  categoryName: string;
  creator: string;
  duration: string;
  views: string;
};

const sampleVideoUrl = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";

export const demoVideos: DemoVideo[] = [
  {
    id: "demo-coast",
    title: "หนึ่งวันริมทะเล เมืองเล็กที่อยากกลับไปอีก",
    description: "พาเดินเล่นริมทะเล แวะร้านกาแฟ และเก็บบรรยากาศของเมืองชายฝั่งไว้ในคลิปเดียว",
    videoUrl: sampleVideoUrl,
    thumbnailUrl: "/demo-thumbnails/city-coast.webp",
    categoryName: "ท่องเที่ยว",
    creator: "บันทึกวันว่าง",
    duration: "08:42",
    views: "12.8K",
  },
  {
    id: "demo-plate",
    title: "จัดจานง่าย ๆ ให้มื้อธรรมดาดูน่ากินขึ้น",
    description: "ไอเดียเล็ก ๆ สำหรับจัดจานอาหารให้น่ามอง โดยใช้วัตถุดิบที่หาได้ในครัว",
    videoUrl: sampleVideoUrl,
    thumbnailUrl: "/demo-thumbnails/fresh-plate.webp",
    categoryName: "อาหาร",
    creator: "ครัวละมุน",
    duration: "06:18",
    views: "8.4K",
  },
  {
    id: "demo-studio",
    title: "เริ่มทำคลิปที่บ้าน: จัดมุมถ่ายด้วยของที่มี",
    description: "จัดมุมถ่ายวิดีโอให้น่าดูขึ้นด้วยแสงธรรมชาติ โทรศัพท์ และอุปกรณ์พื้นฐาน",
    videoUrl: sampleVideoUrl,
    thumbnailUrl: "/demo-thumbnails/creator-studio.webp",
    categoryName: "ไลฟ์สไตล์",
    creator: "โต๊ะทำงานเล่าเรื่อง",
    duration: "11:05",
    views: "6.2K",
  },
  {
    id: "demo-dinner",
    title: "ไอเดียมื้อเย็นสำหรับวันที่ไม่อยากคิดเมนู",
    description: "รวมเมนูสบาย ๆ ที่ทำตามได้ไม่ยาก เหมาะกับวันที่อยากได้มื้ออร่อยแบบไม่ยุ่งยาก",
    videoUrl: sampleVideoUrl,
    thumbnailUrl: "/demo-thumbnails/food-spread.webp",
    categoryName: "อาหาร",
    creator: "ครัวละมุน",
    duration: "09:31",
    views: "19.1K",
  },
  {
    id: "demo-night",
    title: "เดินเล่นหลังพระอาทิตย์ตกในเมืองที่ไม่เคยหลับ",
    description: "บันทึกแสง สี และเสียงของเมืองในช่วงเวลาที่ถนนเริ่มมีชีวิตชีวา",
    videoUrl: sampleVideoUrl,
    thumbnailUrl: "/demo-thumbnails/city-night.webp",
    categoryName: "ท่องเที่ยว",
    creator: "บันทึกวันว่าง",
    duration: "13:16",
    views: "24.7K",
  },
  {
    id: "demo-recipe",
    title: "สูตรง่ายในครัวเล็ก ๆ ที่ทำซ้ำได้ทุกวัน",
    description: "ชวนทำอาหารจานโปรดแบบทีละขั้น พร้อมเทคนิคจัดเตรียมวัตถุดิบให้ทำงานง่ายขึ้น",
    videoUrl: sampleVideoUrl,
    thumbnailUrl: "/demo-thumbnails/recipe-table.webp",
    categoryName: "อาหาร",
    creator: "ครัวละมุน",
    duration: "07:54",
    views: "4.9K",
  },
];

export const demoCategories = ["ท่องเที่ยว", "อาหาร", "ไลฟ์สไตล์"];
