import { useMemo, useState } from "react";
import { ArrowRight, Clapperboard, Compass, LoaderCircle, Search, Shield, Sparkles, X } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { demoCategories, demoVideos } from "@/data/demoVideos";
import VideoCard, { type VideoCardData } from "@/components/VideoCard";

export default function Home() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("ทั้งหมด");
  const videosQuery = trpc.videos.list.useQuery(undefined, { retry: 1 });
  const categoriesQuery = trpc.categories.list.useQuery(undefined, { retry: 1 });

  const realVideos: VideoCardData[] = useMemo(
    () => (videosQuery.data ?? []).map(video => ({
      id: String(video.id),
      title: video.title,
      description: video.description,
      thumbnailUrl: video.thumbnailUrl,
      categoryName: video.categoryName,
      creator: "ClipHub",
    })),
    [videosQuery.data],
  );
  const usingDemo = videosQuery.isSuccess && realVideos.length === 0;
  const sourceVideos = usingDemo ? demoVideos : realVideos;
  const categories = useMemo(() => {
    const fromDb = categoriesQuery.data?.map(category => category.name) ?? [];
    const fromVideos = realVideos.map(video => video.categoryName).filter((name): name is string => Boolean(name));
    return fromDb.length ? fromDb : (fromVideos.length ? Array.from(new Set(fromVideos)) : demoCategories);
  }, [categoriesQuery.data, realVideos]);
  const filteredVideos = useMemo(() => {
    const normalized = search.trim().toLocaleLowerCase("th");
    return sourceVideos.filter(video => {
      const matchesCategory = activeCategory === "ทั้งหมด" || video.categoryName === activeCategory;
      const haystack = `${video.title} ${video.description ?? ""} ${video.categoryName ?? ""} ${"creator" in video ? video.creator : ""}`.toLocaleLowerCase("th");
      return matchesCategory && (!normalized || haystack.includes(normalized));
    });
  }, [activeCategory, search, sourceVideos]);

  return (
    <div className="site-shell">
      <header className="topbar">
        <Link href="/" className="brand" aria-label="ClipHub หน้าแรก">
          <span className="brand-mark"><Clapperboard size={20} strokeWidth={2.4} /></span>
          <span className="brand-name">Clip<span>Hub</span></span>
        </Link>
        <div className="topbar__search">
          <Search size={18} />
          <input
            value={search}
            onChange={event => setSearch(event.target.value)}
            placeholder="ค้นหาคลิปที่อยากดู..."
            aria-label="ค้นหาคลิปวิดีโอ"
          />
          {search && <button className="icon-button search-clear" onClick={() => setSearch("")} aria-label="ล้างคำค้น"><X size={16} /></button>}
        </div>
        <Link href="/admin" className="admin-link">
          <Shield size={17} />
          <span>สำหรับแอดมิน</span>
        </Link>
      </header>

      <main className="home-main">
        <section className="intro-panel">
          <div className="intro-copy">
            <div className="eyebrow"><span className="eyebrow-dot" /> เปิดดูเรื่องใหม่ได้ทุกวัน</div>
            <h1>คลิปดี ๆ<br /><span>เริ่มได้ที่นี่</span></h1>
            <p>พื้นที่รวมเรื่องน่าดูจากหลายมุม เลือกหมวดที่ชอบแล้วกดเล่นได้เลย</p>
          </div>
          <div className="intro-stamp" aria-hidden="true">
            <span className="stamp-ring">PLAY · PAUSE · REPEAT · </span>
            <span className="stamp-core"><PlayMark /></span>
          </div>
          <div className="intro-bottom">
            <span><Sparkles size={15} /> วิดีโอคัดมาให้ดูเพลิน</span>
            <span className="intro-bottom__right">CLIPHUB / 01</span>
          </div>
        </section>

        <nav className="category-nav" aria-label="เลือกหมวดหมู่วิดีโอ">
          <div className="category-nav__lead"><Compass size={16} /> สำรวจหมวด</div>
          <div className="category-pills">
            {["ทั้งหมด", ...categories].map(category => (
              <button
                key={category}
                className={`category-pill ${activeCategory === category ? "is-active" : ""}`}
                onClick={() => setActiveCategory(category)}
                aria-pressed={activeCategory === category}
              >{category}</button>
            ))}
          </div>
        </nav>

        <section className="video-section">
          <div className="section-heading">
            <div>
              <p className="section-kicker">เลือกดูต่อได้เลย</p>
              <h2>{search ? `ผลการค้นหา “${search}”` : activeCategory === "ทั้งหมด" ? "คลิปที่น่าดูวันนี้" : activeCategory}</h2>
            </div>
            <div className="section-count">
              {usingDemo && <span className="demo-label">ตัวอย่าง</span>}
              <span>{filteredVideos.length.toString().padStart(2, "0")} คลิป</span>
            </div>
          </div>

          {videosQuery.isLoading ? (
            <div className="empty-state empty-state--loading"><LoaderCircle className="loading-orbit-icon" size={23} /><h3>กำลังโหลดคลิป</h3><p>กำลังดึงรายการวิดีโอจาก ClipHub</p></div>
          ) : videosQuery.isError ? (
            <div className="empty-state"><span className="empty-state__icon"><Search size={22} /></span><h3>โหลดคลิปไม่สำเร็จ</h3><p>ยังดึงรายการวิดีโอไม่ได้ ลองใหม่อีกครั้ง</p><button className="text-button" onClick={() => void videosQuery.refetch()}>ลองอีกครั้ง <ArrowRight size={16} /></button></div>
          ) : filteredVideos.length ? (
            <div className="video-grid">
              {filteredVideos.map(video => <VideoCard key={video.id} video={video} />)}
            </div>
          ) : (
            <div className="empty-state">
              <span className="empty-state__icon"><Search size={22} /></span>
              <h3>ยังไม่เจอคลิปที่ตรงกัน</h3>
              <p>ลองค้นหาด้วยคำอื่น หรือเลือกหมวดหมู่ใหม่</p>
              <button className="text-button" onClick={() => { setSearch(""); setActiveCategory("ทั้งหมด"); }}>ดูคลิปทั้งหมด <ArrowRight size={16} /></button>
            </div>
          )}
        </section>

        <footer className="site-footer">
          <Link href="/" className="footer-brand"><Clapperboard size={17} /> ClipHub</Link>
          <span>เรื่องดี ๆ มีให้ดูอีกเสมอ</span>
          <a href="https://unsplash.com/license" target="_blank" rel="noreferrer">ภาพปกตัวอย่างจาก Unsplash</a>
        </footer>
      </main>
    </div>
  );
}

function PlayMark() {
  return <span className="play-mark-triangle" />;
}
