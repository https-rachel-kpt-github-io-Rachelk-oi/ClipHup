import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ArrowLeft, Clapperboard, Film, FolderPlus, ImagePlus, LayoutDashboard, LogOut, Pencil, Plus, ShieldCheck, Trash2, Upload, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

type AdminTab = "videos" | "categories";

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.onerror = () => reject(new Error("อ่านไฟล์ไม่สำเร็จ"));
    reader.readAsDataURL(file);
  });
}

function playableSource(value: string) {
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    if (["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtu.be"].includes(host)) return true;
    return url.protocol === "https:" && url.pathname.toLowerCase().endsWith(".mp4");
  } catch {
    return false;
  }
}

export default function AdminPage({ loginOnly = false }: { loginOnly?: boolean }) {
  const [location, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<AdminTab>(location === "/admin/categories" ? "categories" : "videos");
  const adminMe = trpc.auth.adminMe.useQuery(undefined, { retry: false });
  const user = adminMe.data?.authenticated ? { name: "ผู้ดูแลระบบ", email: null, role: "admin" as const } : null;
  const loading = adminMe.isLoading;
  const utils = trpc.useUtils();
  const adminLogin = trpc.auth.adminLogin.useMutation();
  const adminLogout = trpc.auth.adminLogout.useMutation();
  const isAdmin = user?.role === "admin";
  const videoQuery = trpc.videos.adminList.useQuery(undefined, { enabled: Boolean(isAdmin), retry: false });
  const categoryQuery = trpc.categories.adminList.useQuery(undefined, { enabled: Boolean(isAdmin), retry: false });
  const categories = categoryQuery.data ?? [];

  const [formOpen, setFormOpen] = useState(false);
  const [editingVideoId, setEditingVideoId] = useState<number | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState("");
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState("");
  const [formError, setFormError] = useState("");
  const [categoryName, setCategoryName] = useState("");
  const [editingCategoryId, setEditingCategoryId] = useState<number | null>(null);
  const [categoryError, setCategoryError] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const videoDialogRef = useRef<HTMLDivElement>(null);

  const createVideo = trpc.videos.create.useMutation();
  const updateVideo = trpc.videos.update.useMutation();
  const deleteVideo = trpc.videos.delete.useMutation();
  const uploadThumbnail = trpc.videos.uploadThumbnail.useMutation();
  const createCategory = trpc.categories.create.useMutation();
  const updateCategory = trpc.categories.update.useMutation();
  const deleteCategory = trpc.categories.delete.useMutation();

  const loadingAdminData = Boolean(isAdmin) && (videoQuery.isLoading || categoryQuery.isLoading);
  const statusText = useMemo(() => loadingAdminData ? "กำลังโหลดข้อมูล" : `${videoQuery.data?.length ?? 0} คลิปในระบบ`, [loadingAdminData, videoQuery.data]);

  useEffect(() => {
    if (!formOpen) return;
    const dialog = videoDialogRef.current;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const focusable = () => Array.from(dialog?.querySelectorAll<HTMLElement>("button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex='-1'])") ?? []);
    focusable()[0]?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setFormOpen(false);
      }
      if (event.key === "Tab") {
        const items = focusable();
        if (!items.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault(); last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault(); first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      previousFocus?.focus();
    };
  }, [formOpen]);

  function resetVideoForm() {
    setEditingVideoId(null); setTitle(""); setDescription(""); setVideoUrl("");
    setCategoryId(""); setThumbnailUrl(""); setThumbnailFile(null); setFileError(""); setFormError("");
  }

  function openNewVideo() {
    resetVideoForm(); setFormOpen(true);
  }

  function openEditVideo(video: NonNullable<typeof videoQuery.data>[number]) {
    setEditingVideoId(video.id); setTitle(video.title); setDescription(video.description ?? "");
    setVideoUrl(video.videoUrl); setCategoryId(video.categoryId ? String(video.categoryId) : "");
    setThumbnailUrl(video.thumbnailUrl ?? ""); setThumbnailFile(null); setFileError(""); setFormError(""); setFormOpen(true);
  }

  function onChooseFile(file?: File) {
    setFileError("");
    if (!file) { setThumbnailFile(null); return; }
    if (!(["image/jpeg", "image/png", "image/webp"].includes(file.type))) {
      setFileError("เลือกไฟล์ JPG, PNG หรือ WebP"); return;
    }
    if (file.size > 5 * 1024 * 1024) { setFileError("ขนาดไฟล์ต้องไม่เกิน 5 MB"); return; }
    setThumbnailFile(file);
  }

  async function submitVideo(event: FormEvent) {
    event.preventDefault(); setFormError("");
    if (!playableSource(videoUrl.trim())) {
      setFormError("ใส่ลิงก์ YouTube หรือ URL ไฟล์ MP4 ที่ขึ้นต้นด้วย HTTPS"); return;
    }
    try {
      let savedThumbnail = thumbnailUrl || null;
      if (thumbnailFile) {
        const base64Content = await fileToBase64(thumbnailFile);
        const uploaded = await uploadThumbnail.mutateAsync({ fileName: thumbnailFile.name, mimeType: thumbnailFile.type as "image/jpeg" | "image/png" | "image/webp", base64Content });
        savedThumbnail = uploaded.thumbnailUrl;
      }
      const payload = {
        title: title.trim(), description: description.trim() || null, videoUrl: videoUrl.trim(),
        thumbnailUrl: savedThumbnail, categoryId: categoryId ? Number(categoryId) : null,
      };
      if (editingVideoId) await updateVideo.mutateAsync({ id: editingVideoId, ...payload });
      else await createVideo.mutateAsync(payload);
      await Promise.all([utils.videos.adminList.invalidate(), utils.videos.list.invalidate()]);
      setFormOpen(false); resetVideoForm();
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "บันทึกคลิปไม่สำเร็จ");
    }
  }

  async function signIn(event: FormEvent) {
    event.preventDefault(); setLoginError("");
    try {
      const result = await adminLogin.mutateAsync({ username: username.trim(), password });
      sessionStorage.setItem("cliphub-admin-session", result.token);
      setPassword("");
      await utils.auth.adminMe.invalidate();
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : "เข้าสู่ระบบไม่สำเร็จ");
    }
  }

  async function submitCategory(event: FormEvent) {
    event.preventDefault(); setCategoryError("");
    try {
      if (editingCategoryId) await updateCategory.mutateAsync({ id: editingCategoryId, name: categoryName.trim() });
      else await createCategory.mutateAsync({ name: categoryName.trim() });
      setCategoryName(""); setEditingCategoryId(null);
      await Promise.all([utils.categories.adminList.invalidate(), utils.categories.list.invalidate(), utils.videos.list.invalidate()]);
    } catch (error) {
      setCategoryError(error instanceof Error ? error.message : "บันทึกหมวดหมู่ไม่สำเร็จ");
    }
  }

  function beginEditCategory(category: { id: number; name: string }) {
    setEditingCategoryId(category.id); setCategoryName(category.name); setCategoryError("");
  }

  async function removeVideo(id: number) {
    if (!window.confirm("ต้องการลบคลิปนี้หรือไม่? การลบรายการนี้ย้อนกลับไม่ได้")) return;
    try { await deleteVideo.mutateAsync({ id }); await Promise.all([utils.videos.adminList.invalidate(), utils.videos.list.invalidate()]); }
    catch (error) { window.alert(error instanceof Error ? error.message : "ลบคลิปไม่สำเร็จ"); }
  }

  async function removeCategory(category: { id: number; name: string }) {
    if (!window.confirm(`ลบหมวดหมู่ “${category.name}” หรือไม่? คลิปที่อยู่ในหมวดนี้จะยังอยู่ แต่จะไม่มีหมวดหมู่`)) return;
    try {
      await deleteCategory.mutateAsync({ id: category.id });
      await Promise.all([utils.categories.adminList.invalidate(), utils.categories.list.invalidate(), utils.videos.adminList.invalidate(), utils.videos.list.invalidate()]);
      if (editingCategoryId === category.id) { setEditingCategoryId(null); setCategoryName(""); }
    } catch (error) { window.alert(error instanceof Error ? error.message : "ลบหมวดหมู่ไม่สำเร็จ"); }
  }

  async function signOut() {
    try { await adminLogout.mutateAsync(); }
    finally {
      try { sessionStorage.removeItem("cliphub-admin-session"); } catch {}
      utils.auth.adminMe.setData(undefined, { authenticated: false });
      setLocation("/");
    }
  }

  if (loading) return <div className="page-loading"><span className="loading-orbit" /> กำลังตรวจสอบบัญชี...</div>;

  if (!user) {
    return (
      <div className="admin-gate">
        <Link href="/" className="brand"><span className="brand-mark"><Clapperboard size={20} /></span><span className="brand-name">Clip<span>Hub</span></span></Link>
        <div className="gate-card">
          <span className="gate-icon"><ShieldCheck size={25} /></span>
          <p className="section-kicker">พื้นที่สำหรับผู้ดูแล</p>
          <h1>{loginOnly ? "เข้าสู่ระบบแอดมิน" : "จัดการคลิปของคุณ"}</h1>
          <p>กรอกชื่อผู้ใช้และรหัสผ่านของผู้ดูแล เพื่อเพิ่มคลิป อัปโหลดภาพปก และจัดหมวดหมู่</p>
          <form className="admin-login-form" onSubmit={event => void signIn(event)}>
            <div className="field-group"><label htmlFor="admin-username">ชื่อผู้ใช้</label><input id="admin-username" autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} maxLength={128} required /></div>
            <div className="field-group"><label htmlFor="admin-password">รหัสผ่าน</label><input id="admin-password" type="password" autoComplete="current-password" value={password} onChange={event => setPassword(event.target.value)} maxLength={256} required /></div>
            {loginError && <div className="inline-error" role="alert">{loginError}</div>}
            <button className="primary-button primary-button--wide" type="submit" disabled={adminLogin.isPending}><ShieldCheck size={17} /> {adminLogin.isPending ? "กำลังตรวจสอบ..." : "เข้าสู่ระบบหลังบ้าน"}</button>
          </form>
          <Link href="/" className="gate-back"><ArrowLeft size={15} /> กลับไปดูคลิป</Link>
        </div>
        <span className="gate-footnote">Session แอดมินเก็บไว้เฉพาะแท็บนี้และหมดอายุภายใน 2 ชั่วโมง</span>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="admin-gate">
        <Link href="/" className="brand"><span className="brand-mark"><Clapperboard size={20} /></span><span className="brand-name">Clip<span>Hub</span></span></Link>
        <div className="gate-card">
          <span className="gate-icon gate-icon--muted"><ShieldCheck size={25} /></span>
          <p className="section-kicker">จำกัดสิทธิ์การเข้าถึง</p>
          <h1>บัญชีนี้ยังไม่มีสิทธิ์แอดมิน</h1>
          <p>เข้าสู่ระบบแล้วในชื่อ {user.name || user.email || "ผู้ใช้ ClipHub"} แต่บัญชีนี้ไม่ได้รับสิทธิ์ผู้ดูแลเว็บไซต์</p>
          <button className="secondary-button primary-button--wide" onClick={signOut}><LogOut size={16} /> ออกจากระบบ</button>
          <Link href="/" className="gate-back"><ArrowLeft size={15} /> กลับไปดูคลิป</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <Link href="/" className="brand"><span className="brand-mark"><Clapperboard size={20} /></span><span className="brand-name">Clip<span>Hub</span></span></Link>
        <div className="admin-sidebar__label">STUDIO</div>
        <button className={`admin-nav-item ${activeTab === "videos" ? "is-active" : ""}`} onClick={() => { setActiveTab("videos"); setLocation("/admin"); }}><LayoutDashboard size={17} /> ภาพรวมคลิป</button>
        <button className={`admin-nav-item ${activeTab === "categories" ? "is-active" : ""}`} onClick={() => { setActiveTab("categories"); setLocation("/admin/categories"); }}><FolderPlus size={17} /> หมวดหมู่</button>
        <div className="admin-sidebar__bottom">
          <div className="admin-user"><span className="creator-avatar">{(user.name || "A").slice(0, 1)}</span><div><strong>{user.name || "แอดมิน"}</strong><small>ผู้ดูแลระบบ</small></div></div>
          <button className="admin-nav-item" onClick={signOut}><LogOut size={17} /> ออกจากระบบ</button>
          <Link href="/" className="admin-nav-item"><ArrowLeft size={17} /> กลับหน้าเว็บไซต์</Link>
        </div>
      </aside>

      <main className="admin-main">
        <header className="admin-topbar">
          <div><p className="section-kicker">CLIPHUB STUDIO</p><h1>{activeTab === "videos" ? "จัดการคลิป" : "จัดการหมวดหมู่"}</h1></div>
          <div className="admin-topbar__status"><span className="status-dot" /> ระบบพร้อมใช้งาน</div>
        </header>

        {activeTab === "videos" ? (
          <section className="admin-content">
            <div className="admin-toolbar">
              <div><h2>คลิปทั้งหมด</h2><p>{statusText} · แก้ไขข้อมูลและภาพปกได้จากรายการนี้</p></div>
              <button className="primary-button" onClick={openNewVideo}><Plus size={17} /> เพิ่มคลิป</button>
            </div>
            {videoQuery.error && <div className="inline-error">โหลดคลิปไม่สำเร็จ: {videoQuery.error.message}</div>}
            {loadingAdminData ? <div className="admin-loading">กำลังโหลดรายการคลิป...</div> : videoQuery.data?.length ? (
              <div className="admin-video-list">
                {videoQuery.data.map(video => (
                  <article className="admin-video-row" key={video.id}>
                    <div className="admin-video-thumb">{video.thumbnailUrl ? <img src={video.thumbnailUrl} alt="" /> : <span><Film size={20} /></span>}</div>
                    <div className="admin-video-info"><span className="video-card__category">{video.categoryName || "ทั่วไป"}</span><h3>{video.title}</h3><p>{video.videoUrl}</p></div>
                    <div className="admin-video-actions"><button className="icon-button" onClick={() => openEditVideo(video)} aria-label={`แก้ไข ${video.title}`}><Pencil size={17} /></button><button className="icon-button icon-button--danger" onClick={() => void removeVideo(video.id)} aria-label={`ลบ ${video.title}`}><Trash2 size={17} /></button></div>
                  </article>
                ))}
              </div>
            ) : (
              <div className="admin-empty"><span><Film size={24} /></span><h3>ยังไม่มีคลิปในระบบ</h3><p>เพิ่มคลิปแรกของคุณ พร้อมลิงก์วิดีโอและภาพปก</p><button className="secondary-button" onClick={openNewVideo}><Plus size={16} /> เพิ่มคลิปแรก</button></div>
            )}
          </section>
        ) : (
          <section className="admin-content">
            <div className="admin-toolbar">
              <div><h2>หมวดหมู่คลิป</h2><p>เพิ่มหรือเปลี่ยนชื่อหมวด เพื่อให้ผู้ชมค้นพบคลิปได้ง่ายขึ้น</p></div>
            </div>
            <form className="category-create" onSubmit={event => void submitCategory(event)}>
              <div className="field-group"><label htmlFor="category-name">ชื่อหมวดหมู่</label><input id="category-name" value={categoryName} onChange={event => setCategoryName(event.target.value)} placeholder="เช่น ท่องเที่ยว" maxLength={80} required /></div>
              <button className="primary-button" type="submit" disabled={createCategory.isPending || updateCategory.isPending}>{editingCategoryId ? <Pencil size={16} /> : <Plus size={17} />}{editingCategoryId ? "บันทึกชื่อ" : "เพิ่มหมวดหมู่"}</button>
              {editingCategoryId && <button className="secondary-button" type="button" onClick={() => { setEditingCategoryId(null); setCategoryName(""); }}>ยกเลิก</button>}
            </form>
            {categoryError && <div className="inline-error">{categoryError}</div>}
            {categoryQuery.error && <div className="inline-error">โหลดหมวดหมู่ไม่สำเร็จ: {categoryQuery.error.message}</div>}
            {categories.length ? <div className="category-admin-list">{categories.map(category => <div className="category-admin-row" key={category.id}><span className="category-admin-icon"><FolderPlus size={18} /></span><strong>{category.name}</strong><span className="category-admin-slug">/{category.slug}</span><div><button className="icon-button" onClick={() => beginEditCategory(category)} aria-label={`แก้ไข ${category.name}`}><Pencil size={16} /></button><button className="icon-button icon-button--danger" onClick={() => void removeCategory(category)} aria-label={`ลบ ${category.name}`}><Trash2 size={16} /></button></div></div>)}</div> : <div className="admin-empty admin-empty--compact"><span><FolderPlus size={23} /></span><h3>ยังไม่มีหมวดหมู่</h3><p>เพิ่มหมวดแรกเพื่อจัดกลุ่มคลิป</p></div>}
          </section>
        )}
      </main>

      {formOpen && (
        <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) setFormOpen(false); }}>
          <section ref={videoDialogRef} className="video-form-modal" role="dialog" aria-modal="true" aria-labelledby="video-form-title" tabIndex={-1}>
            <div className="modal-heading"><div><p className="section-kicker">CLIPHUB STUDIO</p><h2 id="video-form-title">{editingVideoId ? "แก้ไขคลิป" : "เพิ่มคลิปใหม่"}</h2></div><button className="icon-button" onClick={() => setFormOpen(false)} aria-label="ปิด"><X size={19} /></button></div>
            <form className="video-form" onSubmit={event => void submitVideo(event)}>
              <div className="field-group"><label htmlFor="video-title">ชื่อคลิป</label><input id="video-title" value={title} onChange={event => setTitle(event.target.value)} maxLength={180} placeholder="ตั้งชื่อให้ชวนกดดู" required /></div>
              <div className="field-group"><label htmlFor="video-url">ลิงก์วิดีโอ</label><input id="video-url" type="url" value={videoUrl} onChange={event => setVideoUrl(event.target.value)} placeholder="https://... (MP4 หรือ YouTube)" required /><small>รองรับ URL วิดีโอ MP4 แบบ HTTPS หรือ YouTube</small></div>
              <div className="field-row">
                <div className="field-group"><label htmlFor="video-category">หมวดหมู่</label><select id="video-category" value={categoryId} onChange={event => setCategoryId(event.target.value)}><option value="">ไม่ระบุหมวดหมู่</option>{categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}</select></div>
                <div className="field-group"><label>ภาพปก</label><label className="upload-control"><input type="file" accept="image/jpeg,image/png,image/webp" onChange={event => onChooseFile(event.target.files?.[0])} /><span className="upload-preview">{thumbnailFile ? <img src={URL.createObjectURL(thumbnailFile)} alt="ตัวอย่างภาพปก" /> : thumbnailUrl ? <img src={thumbnailUrl} alt="ภาพปกปัจจุบัน" /> : <ImagePlus size={21} />}</span><span className="upload-copy"><strong>{thumbnailFile ? thumbnailFile.name : thumbnailUrl ? "เลือกภาพใหม่" : "อัปโหลดภาพปก"}</strong><small>JPG, PNG, WebP · ไม่เกิน 5 MB</small></span><Upload size={16} /></label>{fileError && <small className="field-error">{fileError}</small>}</div>
              </div>
              <div className="field-group"><label htmlFor="video-description">รายละเอียด</label><textarea id="video-description" value={description} onChange={event => setDescription(event.target.value)} rows={4} maxLength={5000} placeholder="เล่าให้ผู้ชมรู้ว่าคลิปนี้เกี่ยวกับอะไร" /></div>
              {formError && <div className="inline-error">{formError}</div>}
              <div className="modal-actions"><button className="secondary-button" type="button" onClick={() => setFormOpen(false)}>ยกเลิก</button><button className="primary-button" type="submit" disabled={createVideo.isPending || updateVideo.isPending || uploadThumbnail.isPending}>{uploadThumbnail.isPending ? "กำลังอัปโหลดภาพ..." : editingVideoId ? "บันทึกการแก้ไข" : "เพิ่มคลิป"}</button></div>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}
