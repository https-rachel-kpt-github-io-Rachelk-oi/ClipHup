import { ArrowLeft, Clapperboard, ExternalLink, Play, Share2 } from "lucide-react";
import { Link } from "wouter";
import { demoVideos } from "@/data/demoVideos";
import { trpc } from "@/lib/trpc";
import VideoCard, { type VideoCardData } from "@/components/VideoCard";
import NotFound from "@/pages/NotFound";

type PlayerSource = { kind: "youtube"; src: string } | { kind: "mp4"; src: string } | null;

function resolvePlayerSource(raw: string): PlayerSource {
  try {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase();
    const youtubeHosts = ["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be", "www.youtu.be"];
    if (youtubeHosts.includes(host)) {
      const segments = url.pathname.split("/").filter(Boolean);
      const videoId = host.includes("youtu.be") ? segments[0] : url.searchParams.get("v") || (segments[0] === "embed" || segments[0] === "shorts" ? segments[1] : "");
      if (videoId && /^[\w-]{6,20}$/.test(videoId)) {
        return { kind: "youtube", src: `https://www.youtube-nocookie.com/embed/${videoId}` };
      }
    }
    if (url.protocol === "https:" && url.pathname.toLowerCase().endsWith(".mp4")) {
      return { kind: "mp4", src: url.toString() };
    }
  } catch {
    return null;
  }
  return null;
}

export default function VideoPage({ id }: { id: string }) {
  const demo = demoVideos.find(video => video.id === id);
  const numericId = Number(id);
  const validId = !demo && Number.isInteger(numericId) && numericId > 0;
  const videoQuery = trpc.videos.byId.useQuery({ id: validId ? numericId : 0 }, { enabled: Boolean(validId), retry: false });
  const listQuery = trpc.videos.list.useQuery(undefined, { enabled: Boolean(demo || videoQuery.data), retry: 1 });

  if (!demo && !validId) return <NotFound />;
  if (validId && videoQuery.isLoading) return <div className="page-loading"><span className="loading-orbit" /> กำลังเปิดคลิป...</div>;
  if (validId && (videoQuery.error || !videoQuery.data)) return <NotFound />;

  const video: VideoCardData & { videoUrl: string; description?: string | null } | null = demo
    ? { ...demo, id: demo.id }
    : videoQuery.data
      ? { ...videoQuery.data, id: String(videoQuery.data.id), creator: "ClipHub" }
      : null;
  if (!video) return <NotFound />;

  const source = resolvePlayerSource(video.videoUrl);
  const related: VideoCardData[] = (demo
    ? demoVideos.filter(item => item.id !== demo.id)
    : (listQuery.data ?? []).filter(item => String(item.id) !== video.id).slice(0, 4).map(item => ({
      id: String(item.id), title: item.title, description: item.description,
      thumbnailUrl: item.thumbnailUrl, categoryName: item.categoryName, creator: "ClipHub",
    }))).slice(0, 4);

  return (
    <div className="site-shell">
      <header className="topbar topbar--watch">
        <Link href="/" className="brand"><span className="brand-mark"><Clapperboard size={20} /></span><span className="brand-name">Clip<span>Hub</span></span></Link>
        <Link href="/" className="back-link"><ArrowLeft size={17} /> กลับไปหน้าคลิป</Link>
      </header>
      <main className="watch-main">
        <div className="watch-breadcrumb"><Link href="/">หน้าแรก</Link><span>/</span><span>{video.categoryName || "ทั่วไป"}</span></div>
        <div className="watch-layout">
          <article className="watch-primary">
            <div className="player-frame">
              {source?.kind === "mp4" ? (
                <video key={source.src} controls playsInline preload="metadata" poster={video.thumbnailUrl || undefined}>
                  <source src={source.src} type="video/mp4" />
                  เบราว์เซอร์นี้ไม่รองรับการเล่นวิดีโอ
                </video>
              ) : source?.kind === "youtube" ? (
                <iframe src={source.src} title={video.title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen />
              ) : (
                <div className="player-unavailable">
                  {video.thumbnailUrl && <img src={video.thumbnailUrl} alt="" />}
                  <div className="player-unavailable__content"><span><Play size={18} fill="currentColor" /></span><strong>ยังไม่สามารถเล่นวิดีโอนี้ได้</strong><small>เพิ่มลิงก์ MP4 หรือ YouTube ที่ถูกต้องจากหลังบ้าน</small></div>
                </div>
              )}
            </div>
            {demo && <div className="demo-notice">คลิปตัวอย่างสำหรับดูรูปแบบหน้าเล่นวิดีโอ</div>}
            <div className="watch-title-row">
              <div><span className="watch-category">{video.categoryName || "ทั่วไป"}</span><h1>{video.title}</h1></div>
              <button className="share-button" onClick={() => navigator.clipboard?.writeText(window.location.href).then(() => window.alert("คัดลอกลิงก์แล้ว"))} aria-label="คัดลอกลิงก์คลิป"><Share2 size={17} /></button>
            </div>
            <div className="watch-byline">
              <span className="creator-avatar">{(video.creator || "C").slice(0, 1)}</span>
              <div><strong>{video.creator || "ClipHub"}</strong><small>ครีเอเตอร์บน ClipHub</small></div>
              <span className="watch-byline__spacer" />
              <span className="watch-chip">วิดีโอทั่วไป</span>
            </div>
            {video.description && <p className="watch-description">{video.description}</p>}
          </article>
          <aside className="watch-related">
            <div className="related-heading"><div><p className="section-kicker">ดูต่อได้อีก</p><h2>คลิปแนะนำ</h2></div><ExternalLink size={17} /></div>
            <div className="related-list">{related.map(item => <VideoCard key={item.id} video={item} />)}</div>
          </aside>
        </div>
      </main>
    </div>
  );
}
