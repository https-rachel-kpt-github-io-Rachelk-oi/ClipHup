import { ArrowUpRight, Play } from "lucide-react";
import { Link } from "wouter";

export type VideoCardData = {
  id: string;
  title: string;
  description?: string | null;
  thumbnailUrl?: string | null;
  categoryName?: string | null;
  creator?: string;
  duration?: string;
  views?: string;
};

export default function VideoCard({ video }: { video: VideoCardData }) {
  return (
    <Link href={`/video/${video.id}`} className="video-card" aria-label={`ดูคลิป ${video.title}`}>
      <div className="video-card__image-wrap">
        {video.thumbnailUrl ? (
          <img className="video-card__image" src={video.thumbnailUrl} alt="" loading="lazy" />
        ) : (
          <div className="video-card__placeholder"><Play size={25} fill="currentColor" /></div>
        )}
        <span className="video-card__duration">{video.duration ?? "คลิปใหม่"}</span>
        <span className="video-card__play"><Play size={18} fill="currentColor" /></span>
      </div>
      <div className="video-card__body">
        <div className="video-card__meta">
          <span className="video-card__category">{video.categoryName || "ทั่วไป"}</span>
          {video.views && <span>{video.views} วิว</span>}
        </div>
        <h3>{video.title}</h3>
        <div className="video-card__creator">
          <span className="creator-dot">{(video.creator || "C").slice(0, 1)}</span>
          <span>{video.creator || "ClipHub"}</span>
          <ArrowUpRight className="video-card__arrow" size={15} />
        </div>
      </div>
    </Link>
  );
}
